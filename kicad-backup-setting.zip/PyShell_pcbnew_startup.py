### DEFAULT STARTUP FILE FOR KiCad:PCBNEW Python Shell
# Enter any Python code you would like to execute when the PCBNEW python shell first runs.

# Eg:

import pcbnew
board = pcbnew.GetBoard()

tracks = board.GetTracks()
pads = board.GetPads()

from teardrops import td
td.SetTeardrops()
